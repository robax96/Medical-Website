<?php
session_start();

if($_SESSION['doctor_username'] == '')
{
header("Location: doctor.php");
exit;
}

$var = $_SESSION["doctor_username"];

echo "LOGGED AS DOCTOR ACCOUNT: ".$var;

if(isset($_POST['show_history'])){
	if(!empty($_POST['patient_id'])){
		
		$nhs_propmt = $_POST['patient_id'];
		
		
		if(preg_match("/^[0-9]+$/",$nhs_propmt) and strlen($nhs_propmt) == 10){
			
			/*Shows patient medical history*/

			require('../db_connect.php');

			$pat_query = "SELECT * FROM Patient_history_record WHERE patient_nhsn = '$nhs_propmt'";

			$patient_hist = mysqli_query($conn,$pat_query);

			mysqli_close($conn);
			
			if(mysqli_num_rows($patient_hist)==0){
				$record_result = "NO MEDICAL HISTORY FOUND";
			
			}
			
			
			
			
		}
		else
		{
			$record_result = "Format not valid";
		}
	}
	else
	{
		$record_result = "PLEASE PROMPT AN NHS NUMBER";
	}
}


?>

<html>
<head>
<title>DOCTOR ACCOUNT -- PATIENTS LIST</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">
</head>
<body>
<br><br>
<a href="../gphomepage.html">HOMEPAGE</a><br><br>
<a href="doctoraccount.php">DOCTOR ACCOUNT PAGE</a><br><br>
<a href="doctor.php">LOGOUT</a><br><br><br>

<?php

/*Shows patients list from database*/

require('../db_connect.php');

$pat_query = "SELECT * FROM Patient";

$patients = mysqli_query($conn,$pat_query);

mysqli_close($conn);

echo "<br><br><br>PATIENTS LIST<br><br>";

/*Load results in a table*/

echo "<table border='1' bgcolor='yellow'>";
echo "<tr><td>NHS NUMBER</td><td>Name</td><td>Surname</td><td>Gender</td><td>Date of Birth</td><td>Address</td><td>Phone</td></tr>";

while($row = mysqli_fetch_assoc($patients)){
	echo "<tr><td>{$row['nhs_n']}</td><td>{$row['name']}</td><td>{$row['surname']}</td><td>{$row['Gender']}</td><td>{$row['date_birth']}</td><td>{$row['address']}</td><td>{$row['phone']}</td></tr>";
}
echo "</table>";
?>



<h2>SHOW PATIENT MEDICAL HISTORY</h2>

<form method="post">

<label>PATIENT NHS NUMBER:</label>
  <input type="text" name="patient_id"><?php echo $patient_id_err;?><br><br>
  
<input type="submit" value="SHOW" name="show_history";><br>
</form>

<?php echo $record_result; ?>
  
<?php 

/*SHOWS PATIENT MEDICAL HISTORY*/

if(mysqli_num_rows($patient_hist)>0)
{
	echo "<h3><br>MEDICAL HISTORY FOR NHS N: {$nhs_propmt}<h3><br>";
	echo "<table border='1' bgcolor='orange'>";
	echo "<tr><td>RECORD REF.</td><td>DISEASE</td><td>NOTE/MEDICATION</td><td>DOCTOR ID</td><td>DATE POSTED</td></tr>";

	while($row = mysqli_fetch_assoc($patient_hist)){
		echo "<tr><td>{$row['record_ref']}</td><td>{$row['disease']}</td><td>{$row['note/medication']}</td><td>{$row['doc_id']}</td><td>{$row['date_created']}</td></tr>";
	}
	echo "</table>";
}


?>



 
  
  
  
  
</body>
</html>