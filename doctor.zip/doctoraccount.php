<?php
session_start();

if($_SESSION['doctor_username'] == '')
{
header("Location: doctor.php");
exit;
}

$var = $_SESSION["doctor_username"];
$doctor_id = $_SESSION["doctor_id"];
echo "LOGGED AS DOCTOR ACCOUNT: ".$var;


if(isset($_POST['create_note'])){
	if(!empty($_POST['patient_id']) and !empty($_POST['description']))
	{
		
		$patient_id = $_POST['patient_id'];
		$note_desc = $_POST['description'];
		
		
		/*Check on input formats*/
		
		
		
		if (!preg_match("/^[0-9]+$/",$patient_id)){
			$patient_id_err = "*Only numbers allowed*";
			++$note_add_errs;
		}
		else{
		
			if(strlen($patient_id) != 10){
				$patient_id_err = "*NHS number has 10 digits*";
				++$note_add_errs;
			}
		}
		
		if (!preg_match("/^[a-zA-Z0-9\s]+$/",$note_desc) ){
			$note_desc_err = "*Only letters and numbers allowed*";
			++$note_add_errs;
		}
		
		
		if($note_add_errs==0){
			
			require('../db_connect.php');
			
			$insert_note = "INSERT INTO Note_patient (doc_id,pat_id,description) VALUES ('$doctor_id','$patient_id','$note_desc')";
			if(mysqli_query($conn, $insert_note)){
				$note_result = "Note added: NHS NUMBER: ".$patient_id." DESCRIPTION: ".$note_desc;
			}
			else
			{
				$note_result = "Error: PATIENT NHS NUMBER NOT FOUND!";
			}
			mysqli_close($conn);
		}
		
		
		
		
		
		
	}
	else
	{
		$note_result = "Please complete all fields!!";
	}
		

}

?>

<html>
<head>
<title>DOCTOR ACCOUNT PAGE</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">
</head>


<body>
<br><br>
<a href="../gphomepage.html">HOMEPAGE</a>
<br><br>
<a href="doctor.php">LOGOUT</a>
<br><br>
<a href="patient_list.php">PATIENTS LIST</a>
<br><br><br>

<h1>CREATE PATIENT NOTE</h1>

<form method="post">

  
<label>PATIENT NHS NUMBER:</label>
  <input type="text" name="patient_id"><?php echo $patient_id_err;?><br><br>
  
<label>DESCRIPTION:</label>
  <input type="text" name="description"><?php echo $note_desc_err;?><br><br>
  

  
<input type="submit" value="CREATE" name="create_note";><br>
</form>
<?php echo $note_result; ?>

</body>
</html>