<?php
session_start();
session_destroy();

if(isset($_POST['login'])){
	


	if(!empty($_POST['username']) and !empty($_POST['password']))
	{	
		require('../db_connect.php');
		$usern=$_POST['username'];
		$passwd=$_POST['password'];
		$query_name = "SELECT * FROM Patient WHERE username='$usern'";

		$names=mysqli_query($conn,$query_name);
	
		if(mysqli_num_rows($names)==0){
			$err_msg="Wrong username and/or password!!!";
			
		}
		else
		{	
			while($row = mysqli_fetch_assoc($names)){
				if(password_verify($passwd, $row['password'])){
		
					session_start();
					$_SESSION["patient_id"] = $row['nhs_n'];
					$_SESSION["patient_username"] = $usern;
					header("Location: patientaccount.php");
					exit;
				}
				else
				{
					$err_msg="Wrong username and/or password!!!";
				}
			
			}
		}
	

	}
	else
	{
		$err_msg="Please complete all fields!!!";
		 
	}
	mysqli_close($conn);
}
?>

<html>
<head>
<title>PATIENT LOGIN PAGE</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">


</head>


<body>
<a href="../gphomepage.html">HOMEPAGE</a>
<br><br><br>
<h1>PATIENT LOGIN</h1>

<form method="post">
<a href="patient_create.php">CREATE ACCOUNT</a>
<p><?php echo $err_msg ?></p>

<label>USERNAME:</label>
  <input type="text" name="username"><br><br>
  
<label>PASSWORD:</label>
  <input type="password" name="password" id="pswd"><br><br>
  <input type="checkbox" onclick="pswdvisible()">Show Password
  
 <script>
function pswdvisible() {
  var x = document.getElementById("pswd");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<br><br>

<input type="submit" value="LOGIN" name="login";><br>
</form>


</body>
</html>