<?php
/*Create Patient Account */

if(isset($_POST['create_pat'])){
	if(!empty($_POST['pat_nhsn']) and !empty($_POST['pat_username']) and !empty($_POST['pat_password']) and !empty($_POST['pat_name']) and !empty($_POST['pat_surname']) and !empty($_POST['pat_dob']) and !empty($_POST['pat_address']) and !empty($_POST['pat_phone']))
	{
		
		$pat_nhsn= $_POST['pat_nhsn'];
		$pat_username= $_POST['pat_username'];
		$pat_password= $_POST['pat_password'];
		$pat_name= $_POST['pat_name'];
		$pat_surname= $_POST['pat_surname'];
		$pat_gender= $_POST['pat_gender'];
		$pat_dob= $_POST['pat_dob'];
		$pat_address= $_POST['pat_address'];
		$pat_phone= $_POST['pat_phone'];
		$pat_add_errs = 0;
		
		if (!preg_match("/^[0-9]+$/",$pat_nhsn)){
			$pat_nhsn_err = "*Only numbers allowed*";
			++$pat_add_errs;
		}
		else{
		
			if(strlen($pat_nhsn) != 10){
				$pat_nhsn_err = "*NHS number has 10 digits*";
				++$pat_add_errs;
			}
		}
		
		if (!preg_match("/^[a-zA-Z0-9]+$/",$pat_username)){
			$pat_username_err = "*Only letters and numbers allowed*";
			++$pat_add_errs;
		}
		
		if (preg_match('/\s/',$pat_password)){
			$pat_pswd_err = "*No spaces allowed*";
			++$pat_add_errs;
		}
		
		if (!preg_match("/^[a-zA-Z]+$/",$pat_name)){
			$pat_name_err = "*Only letters allowed*";
			++$pat_add_errs;
		}
		
		if (!preg_match("/^[a-zA-Z]+$/",$pat_surname)){
			$pat_surname_err = "*Only letters allowed*";
			++$pat_add_errs;
		}
		
		
		if (!preg_match("/^[a-zA-Z0-9\s]+$/",$pat_address) ){
			$pat_address_err = "*Only letters and numbers allowed*";
			++$pat_add_errs;
		}
		
		if (!preg_match("/^(\+44\s?7\d{3}|\(?07\d{3}\)?)\s?\d{3}\s?\d{3}$/", $pat_phone)){
			$pat_phone_err = "*Invalid phone number format*";
			++$pat_add_errs;
		}
		
		if($pat_add_errs == 0){
			
			$pat_name = ucfirst(strtolower($pat_name));
			$pat_surname = ucfirst(strtolower($pat_surname));
			$pat_password_hash = password_hash($pat_password, PASSWORD_DEFAULT);
			
			require('../db_connect.php');
			$insert_pat = "INSERT INTO Patient(nhs_n, username, password, name, surname, Gender, date_birth, address, phone) VALUES ('$pat_nhsn','$pat_username','$pat_password_hash','$pat_name','$pat_surname', '$pat_gender', '$pat_dob', '$pat_address', '$pat_phone')";
			
			if (mysqli_query($conn, $insert_pat)) {
				$add_pat_account_result = "New patient record created successfully<br>"."NHS NUMBER: ".$pat_nhsn."<br>Username: ".$pat_username."<br>Password: ****<br>Name: ".$pat_name."<br>Surname: ".$pat_surname."<br>Gender: ".$pat_gender."<br>Date of birth : ".$pat_dob."<br>Address: ".$pat_address."<br>Phone number: ".$pat_phone;
			}
			else 
			{
				$add_pat_account_result = "*** ERROR: USERNAME AND/OR NHS NUMBER ALREADY EXISTING!!! ***<br>" . $sql . "<br>" . mysqli_error($conn);
			}

			mysqli_close($conn);
			
		
		}
	}
	else
	{ 
		$pat_empty = "Please complete all fields!!";
		

	}
	
}
?>
<html>
<head>
<title>CREATE PATIENT PAGE</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">

</head>


<body>
<a href="../gphomepage.html">HOMEPAGE</a>
<br><br>
<a href="patient.php">PATIENT LOGIN</a>
<br><br><br>

<h1>CREATE PATIENT ACCOUNT</h1>
<?php echo $pat_empty; ?>

<form method="post">

<label>NHS NUMBER:</label>
  <input type="text" name="pat_nhsn"><?php echo $pat_nhsn_err;?><br><br>
  
<label>USERNAME:</label>
  <input type="text" name="pat_username"><?php echo $pat_username_err;?><br><br>
  
<label>PASSWORD:</label>
  <input type="text" name="pat_password"><?php echo $pat_pswd_err;?><br><br>
  
<label>NAME:</label>
  <input type="text" name="pat_name"><?php echo $pat_name_err;?><br><br>
  
<label>SURNAME:</label>
  <input type="text" name="pat_surname"><?php echo $pat_surname_err;?><br><br>
  
<label>GENDER:</label>
<select name="pat_gender">
	<option value="M">Male</option>
	<option value="F">Female</option>
</select><br><br>
 
  
<label>DATE OF BIRTH:</label>
  <input type="date" name="pat_dob"
       value="<?php echo date("Y-m-d"); ?>"
       min="1900-01-01" max="<?php echo date("Y-m-d"); ?>"><br><br>
  
<label>ADDRESS:</label>
  <input type="text" name="pat_address"><?php echo $pat_address_err;?><br><br>
  
<label>PHONE NUMBER:</label>
  <input type="text" name="pat_phone"><?php echo $pat_phone_err;?><br><br>
  
<input type="submit" value="CREATE" name="create_pat";><br><br>

<?php echo $add_pat_account_result; ?>


</form>
</body>
</html>