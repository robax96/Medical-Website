<?php
session_start();

if($_SESSION['patient_username'] == '')
{
header("Location: patient.php");
exit;
}

$var = $_SESSION["patient_username"];
$patient_id = $_SESSION["patient_id"];
echo "LOGGED AS PATIENT ACCOUNT: ".$var;


if(isset($_POST['create_booking'])){
	
	
	$doctor_id = $_POST['doctor_id'];
	$date_booking = $_POST['booking_date'];
	
	if(empty($_POST['note_to_doctor']))
	{
		$note_to_doctor = "n/a";
	}
	else
	{
		$note_to_doctor = $_POST['note_to_doctor'];
	}
	
	
	require('../db_connect.php');
	
	$booking_query = "SELECT * FROM Booking WHERE pat_id = '$patient_id' AND date_booking = '$date_booking'";
	$booking_result=mysqli_query($conn,$booking_query);
	mysqli_close($conn);
	
	if(mysqli_num_rows($booking_result)>0){
		$book_res = "Booking already existing for this patient at this date!!!";
	}
	else
	{
		require('../db_connect.php');
		$add_book_query = "INSERT INTO Booking (doc_id,pat_id,date_booking,note)VALUES ('$doctor_id','$patient_id','$date_booking','$note_to_doctor')";
		
		if(mysqli_query($conn, $add_book_query)){
			$book_res = "Booking added:<br>DATE: ".$date_booking."<br>DOCTOR ID: ".$doctor_id."<br>NOTES: ".$note_to_doctor;
		}
		else
		{
			$book_res = "Error";
		}
	}
}



if(isset($_POST['pat_history'])){
	require('../db_connect.php');
	$pat_query = "SELECT * FROM Patient_history_record WHERE patient_nhsn = '$patient_id'";
	$patient_hist = mysqli_query($conn,$pat_query);

	mysqli_close($conn);
			
	if(mysqli_num_rows($patient_hist)==0){
		$record_result = "NO MEDICAL HISTORY FOUND";
			
	}
}


if(isset($_POST['doc_notes'])){
	require('../db_connect.php');
	$notes_query = "SELECT * FROM Note_patient WHERE pat_id = '$patient_id'";
	$patient_notes = mysqli_query($conn,$notes_query);
	mysqli_close($conn);
	
	if(mysqli_num_rows($patient_notes)==0){
		$note_err = "No notes found";
	}
	
}
?>

<html>
<head>
<title>PATIENT ACCOUNT PAGE</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">


</head>


<body>
<br><br>
<a href="../gphomepage.html">HOMEPAGE</a>
<br><br>
<a href="patient.php">LOGOUT</a>
<br><br><br>

<h1>BOOK APPOINTMENT</h1>

<form method="post">

<label>BOOKING DATE:</label>
  <input type="date" name="booking_date"
       value="<?php echo date("Y-m-d"); ?>"
       min="<?php echo date("Y-m-d"); ?>" max="2100-01-01"><br><br>
  
  
  
<?php
require('../db_connect.php');
$doctors_query = "SELECT ID, name, surname from Doctor";
$doctors_id=mysqli_query($conn,$doctors_query);
mysqli_close($conn);
?>
<label>DOCTOR:</label>
  <select name="doctor_id">
	<?php
	while($row = mysqli_fetch_assoc($doctors_id)){
	?>
	<option value="<?php echo $row['ID']; ?>"><?php echo $row['name']; echo " ".$row['surname']; ?></option>
	
	<?php 
	}?>
	
</select><br><br>
  
<label>NOTE FOR DOCTOR:</label>
  <input type="text" name="note_to_doctor"><br><br>
  

  
<input type="submit" value="CREATE BOOKING" name="create_booking";><br>
</form>

<?php echo $book_res; ?>

<br><br>
<form method="post">
<input type="submit" value="SEE MEDICAL HISTORY" name="pat_history";><br>
</form>


<?php echo $record_result; ?>

<?php 

/*SHOWS PATIENT MEDICAL HISTORY*/

if(mysqli_num_rows($patient_hist)>0)
{
	echo "<h3><br>MEDICAL HISTORY FOR NHS N: {$patient_id}<h3><br>";
	echo "<table border='1' bgcolor='orange'>";
	echo "<tr><td>RECORD REF.</td><td>DISEASE</td><td>NOTE/MEDICATION</td><td>DOCTOR ID</td><td>DATE POSTED</td></tr>";

	while($row = mysqli_fetch_assoc($patient_hist)){
		echo "<tr><td>{$row['record_ref']}</td><td>{$row['disease']}</td><td>{$row['note/medication']}</td><td>{$row['doc_id']}</td><td>{$row['date_created']}</td></tr>";
	}
	echo "</table>";
}


?>



<br><br>
<form method="post">
<input type="submit" value="SEE DOCTOR NOTES" name="doc_notes";><br>
</form>

<?php
if(mysqli_num_rows($patient_notes)>0)
{
	echo "<h3><br>DOCTORS NOTES FOR NHS N: {$patient_id}<h3><br>";
	echo "<table border='1' bgcolor='orange'>";
	echo "<tr><td>DOCTOR ID</td><td>DESCRIPTION</td></tr>";
	while($row = mysqli_fetch_assoc($patient_notes)){
		echo "<tr><td>{$row['doc_id']}</td><td>{$row['description']}</td></tr>";
	}
	echo "</table>";
}
echo $note_err; 
?>





</body>
</html>