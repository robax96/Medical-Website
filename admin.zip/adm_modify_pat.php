<?php
session_start();

if($_SESSION['admin_username'] == '' or $_SESSION['patient_nhs'] == '')
{
	header("Location: admin.php");
	exit;
}

$var = $_SESSION["admin_username"];
echo "LOGGED AS ADMIN ACCOUNT: ".$var;

$pat_nhs = $_SESSION['patient_nhs'];
echo "<br><br>PATIENT NHS N: ".$pat_nhs;


/*Load patient details in the input boxes*/

require('../db_connect.php');
$load_query = "SELECT * FROM Patient WHERE nhs_n='$pat_nhs'";
$pat_details = mysqli_query($conn,$load_query);

while($row = mysqli_fetch_assoc($pat_details)){
	$pat_name = $row['name'];
	$pat_surname = $row['surname'];
	$pat_gender = $row['Gender'];
	$pat_dob = $row['date_birth'];
	$pat_address = $row['address'];
	$pat_phone = $row['phone'];
}

mysqli_close($conn);
	




	
/*Check changes */
	
if(isset($_POST['change_details'])){
	if(!empty($_POST['pat_name']) and !empty($_POST['pat_surname']) and !empty($_POST['pat_dob']) and !empty($_POST['pat_address']) and !empty($_POST['pat_phone']))
	{	
		
		$pat_name= $_POST['pat_name'];
		$pat_surname= $_POST['pat_surname'];
		$pat_gender= $_POST['pat_gender'];
		$pat_dob= $_POST['pat_dob'];
		$pat_address= $_POST['pat_address'];
		$pat_phone= $_POST['pat_phone'];
		
		
		/*Saves backup of original patient details*/
		
		require('../db_connect.php');
		$load_query = "SELECT * FROM Patient WHERE nhs_n='$pat_nhs'";
		$pat_details = mysqli_query($conn,$load_query);
		
		while($row = mysqli_fetch_assoc($pat_details)){
			$pat_name_ini = $row['name'];
			$pat_surname_ini = $row['surname'];
			$pat_gender_ini = $row['Gender'];
			$pat_dob_ini = $row['date_birth'];
			$pat_address_ini = $row['address'];
			$pat_phone_ini = $row['phone'];
		}
		
		mysqli_close($conn);
		
		
		/*Input format checks*/
		
		if (!preg_match("/^[a-zA-Z]+$/",$pat_name)){
			$pat_name_err = "*Only letters allowed*";
			++$pat_add_errs;
		}
		
		if (!preg_match("/^[a-zA-Z]+$/",$pat_surname)){
			$pat_surname_err = "*Only letters allowed*";
			++$pat_add_errs;
		}
		
		
		if (!preg_match("/^[a-zA-Z0-9\s]+$/",$pat_address) ){
			$pat_address_err = "*Only letters and numbers allowed*";
			++$pat_add_errs;
		}
		
		if (!preg_match("/^(\+44\s?7\d{3}|\(?07\d{3}\)?)\s?\d{3}\s?\d{3}$/", $pat_phone)){
			$pat_phone_err = "*Invalid phone number format*";
			++$pat_add_errs;
		}
		
		
		/*If no errors, checks if original details have been changed*/
		
		if($pat_add_errs == 0){
			if($pat_name == $pat_name_ini and $pat_surname == $pat_surname_ini and $pat_gender == $pat_gender_ini and $pat_dob == $pat_dob_ini and $pat_address == $pat_address_ini and $pat_phone == $pat_phone_ini){
				$add_pat_account_result = "*NO CHANGES MADE!*";
			}
			else
			{
				/*If no format errors and details have been changes, it updates record*/
				require('../db_connect.php');
				$update_query = "UPDATE Patient SET name='$pat_name', surname='$pat_surname', Gender='$pat_gender', date_birth='$pat_dob', address='$pat_address', phone='$pat_phone' WHERE nhs_n='$pat_nhs'";
				if (mysqli_query($conn, $update_query)){
					$add_pat_account_result = "PATIENT DETAILS UPDATED SUCCESSFULLY<br>Name: ".$pat_name."<br>Surname: ".$pat_surname."<br>Gender: ".$pat_gender."<br>Date of birth: ".$pat_dob."<br>Address: ".$pat_address."<br>Phone number: ".$pat_phone;
				}
				else 
				{
					$add_pat_account_result = $sql . "<br>Error request:<br>" . mysqli_error($conn);
				}
			}
			
		}

	
	}
	else
	{
		$add_pat_account_result = "*All field must be completed!!*";
	}
}
	
	
	
	
	
	
	
	
?>


<html>
<head>
<title>ADMIN ACCOUNT PAGE--CHANGE PATIENT DETAILS</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">


</head>


<body>
<br><br>
<a href="../gphomepage.html">HOMEPAGE</a>
<br><br>
<a href="admin.php">LOGOUT</a>
<br><br>
<a href="adminaccount.php">ADMIN ACCOUNT PAGE</a>
<br><br><br>
<form method="post">
<h1>CHANGE PATIENT PERSONAL DETAILS</h1>
<?php echo $pat_empty; ?>
  
<label>NAME:</label>
  <input type="text" name="pat_name" value="<?php echo $pat_name; ?>"><?php echo $pat_name_err;?>
  <br><br>
  
<label>SURNAME:</label>
  <input type="text" name="pat_surname" value="<?php echo $pat_surname; ?>"><?php echo $pat_surname_err;?>
  <br><br>
  
<label>GENDER:</label>
<select name="pat_gender">
	<option selected="selected" value="<?php echo $pat_gender; ?>">
	<?php 
	if($pat_gender == 'M'){
		echo "Male";
	}
	else
	{
		echo "Female"; 
	}
	?></option>
	
	<option value="<?php 
	if($pat_gender == 'M'){
		echo "F";
	}
	else
	{
		echo "M"; 
	}
	?>">
	<?php 
	if($pat_gender == 'M'){
		echo "Female";
	}
	else
	{
		echo "Male"; 
	}
	?>
	</option>
</select>

<br><br>
 
  
<label>DATE OF BIRTH:</label>
  <input type="date" name="pat_dob"
       value="<?php echo $pat_dob; ?>"
       min="1900-01-01" max="<?php echo date("Y-m-d"); ?>">
	   <br><br>
  
<label>ADDRESS:</label>
  <input type="text" name="pat_address" value="<?php echo $pat_address; ?>"><?php echo $pat_address_err;?>
  <br><br>
  
<label>PHONE NUMBER:</label>
  <input type="text" name="pat_phone" value="<?php echo $pat_phone; ?>"><?php echo $pat_phone_err;?>
  <br><br><input type="submit" value="UPDATE DETAILS" name="change_details";><br><br>
  


<?php echo $add_pat_account_result; ?>


</form>

</body>
</html>
