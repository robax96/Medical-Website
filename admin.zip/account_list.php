<?php

session_start();

if($_SESSION['admin_username'] == '')
{
	header("Location: admin.php");
	exit;
}

$var = $_SESSION["admin_username"];
echo "LOGGED AS ADMIN ACCOUNT: ".$var;


?>


<html>
<head>
<title>Accounts List</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">
</head>
<body>
<br><br>
<a href="../gphomepage.html">HOMEPAGE</a><br><br>
<a href="adminaccount.php">ADMIN ACCOUNT PAGE</a><br><br>
<a href="admin.php">LOGOUT</a><br><br><br>

<?php

/*Shows doctors list from database*/

require('../db_connect.php');

$doc_query = "SELECT * FROM Doctor";

$doctors = mysqli_query($conn,$doc_query);

mysqli_close($conn);

echo "DOCTOR ACCOUNTS LIST<br><br>";

/*Load results in a table*/

echo "<table border='1' bgcolor='yellow'>";
echo "<tr><td>ID</td><td>Username</td><td>Password</td><td>Name</td><td>Surname</td><td>Phone</td></tr>";

while($row = mysqli_fetch_assoc($doctors)){
	echo "<tr><td>{$row['ID']}</td><td>{$row['username']}</td><td>******</td><td>{$row['name']}</td><td>{$row['surname']}</td><td>{$row['phone']}</td></tr>";
}
echo "</table>";


/*Shows patients list from database*/

require('../db_connect.php');

$pat_query = "SELECT * FROM Patient";

$patients = mysqli_query($conn,$pat_query);

mysqli_close($conn);

echo "<br><br><br>PATIENT ACCOUNTS LIST<br><br>";

/*Load results in a table*/

echo "<table border='1' bgcolor='yellow'>";
echo "<tr><td>NHS NUMBER</td><td>Username</td><td>Password</td><td>Name</td><td>Surname</td><td>Gender</td><td>Date of Birth</td><td>Address</td><td>Phone</td></tr>";

while($row = mysqli_fetch_assoc($patients)){
	echo "<tr><td>{$row['nhs_n']}</td><td>{$row['username']}</td><td>******</td><td>{$row['name']}</td><td>{$row['surname']}</td><td>{$row['Gender']}</td><td>{$row['date_birth']}</td><td>{$row['address']}</td><td>{$row['phone']}</td></tr>";
}
echo "</table>";
?>

</body>
</html>