<?php
session_start();

if($_SESSION['admin_username'] == '')
{
	header("Location: admin.php");
	exit;
}

$var = $_SESSION["admin_username"];
echo "LOGGED AS ADMIN ACCOUNT: ".$var;

/*Create Doctor Account */

if(isset($_POST['create_doc'])){
	if(!empty($_POST['doc_id']) and !empty($_POST['doc_username']) and !empty($_POST['doc_password']) and !empty($_POST['doc_name']) and !empty($_POST['doc_surname']) and !empty($_POST['doc_phone']))
	{
		$doc_id= $_POST['doc_id'];
		$doc_username= $_POST['doc_username'];
		$doc_password= $_POST['doc_password'];
		$doc_name= $_POST['doc_name'];
		$doc_surname= $_POST['doc_surname'];
		$doc_phone= $_POST['doc_phone'];
		$doc_add_errs = 0;
		
		/*Validates input format*/
		
		if (!preg_match("/^[0-9]+$/",$doc_id)){
			$doc_id_err = "*Only numbers allowed*";
			++$doc_add_errs;
		}
		else{
		
			if(strlen($doc_id) > 5){
				$doc_id_err = "*Max 5 digits*";
				++$doc_add_errs;
			}
		}
		
		if (!preg_match("/^[a-zA-Z0-9]+$/",$doc_username)){
			$doc_username_err = "*Only letters and numbers allowed*";
			++$doc_add_errs;
		}
		
		if (preg_match('/\s/',$doc_password)){
			$doc_pswd_err = "*No spaces allowed*";
			++$doc_add_errs;
		}
		
		if (!preg_match("/^[a-zA-Z]+$/",$doc_name)){
			$doc_name_err = "*Only letters allowed*";
			++$doc_add_errs;
		}
		
		if (!preg_match("/^[a-zA-Z]+$/",$doc_surname)){
			$doc_surname_err = "*Only letters allowed*";
			++$doc_add_errs;
		}
		
		if (!preg_match("/^(\+44\s?7\d{3}|\(?07\d{3}\)?)\s?\d{3}\s?\d{3}$/", $doc_phone)){
			$doc_phone_err = "*Invalid phone number format*";
			++$doc_add_errs;
		}
		
		/*If no errors, query will be created*/
		
		if($doc_add_errs == 0){
			$doc_name = ucfirst(strtolower($doc_name));
			$doc_surname = ucfirst(strtolower($doc_surname));
			$doc_password_hash = password_hash($doc_password, PASSWORD_DEFAULT);
			
			require('../db_connect.php');
			$insert_doc = "INSERT INTO Doctor(ID, username, password, name, surname, phone) VALUES ('$doc_id','$doc_username','$doc_password_hash','$doc_name','$doc_surname','$doc_phone')";
			
			/*If id or username already exist, it will give error*/
			
			if (mysqli_query($conn, $insert_doc)) {
				$add_doc_account_result = "New doctor record created successfully<br>"."ID: ".$doc_id."<br>Username: ".$doc_username."<br>Password: ****<br>Name: ".$doc_name."<br>Surname: ".$doc_surname."<br>Phone number: ".$doc_phone;
			}
			else 
			{
				$add_doc_account_result = "*** ERROR: USERNAME AND/OR ID ALREADY EXISTING!!! ***<br>" . $sql . "<br>" . mysqli_error($conn);
			}

			mysqli_close($conn);
			
		}
		
	}
	else
	{ 
		$doc_empty = "Please complete all fields!!";
		

	}
		
		

}


/*Search patient by nhs number */

if(isset($_POST['find_nhs'])){
	if(!empty($_POST['pat_nhs_search'])){
		
		$nhs_propmt = $_POST['pat_nhs_search'];
		
		
		if(preg_match("/^[0-9]+$/",$nhs_propmt) and strlen($nhs_propmt) == 10){
			require('../db_connect.php');
			$nhs_search = "SELECT * FROM Patient WHERE nhs_n='$nhs_propmt'";
	
			$result = mysqli_query($conn,$nhs_search);
	
			if(mysqli_num_rows($result)==0){
				$err_search = "*No patient record found!!!*<br>";
			}
			else
			{
		
				$_SESSION["patient_nhs"] = $nhs_propmt;
				header("Location: adm_modify_pat.php");
				exit;
			}
		}
		else
		{
			$err_search = "*NHS number format not valid!!*<br>";
		}
	}
	else
	{
		$err_search = "*Please prompt an nhs number!!*<br>";
	}
}

?>

<html>
<head>
<title>ADMIN ACCOUNT PAGE</title>
<link rel="stylesheet" type="text/css" href="../webstyle.css">


</head>


<body>
<br><br>
<a href="../gphomepage.html">HOMEPAGE</a><br><br>
<a href="admin.php">LOGOUT</a><br><br>
<a href="account_list.php">ACCOUNTS LIST</a>
<br><br><br>

<h1>CREATE DOCTOR ACCOUNT</h1>


<form method="post">

<label>ID:</label>
  <input type="text" name="doc_id"><?php echo $doc_id_err;?><br><br>
  
<label>USERNAME:</label>
  <input type="text" name="doc_username"><?php echo $doc_username_err;?><br><br>
  
<label>PASSWORD:</label>
  <input type="text" name="doc_password"><?php echo $doc_pswd_err;?><br><br>
  
<label>NAME:</label>
  <input type="text" name="doc_name"><?php echo $doc_name_err;?><br><br>
  
<label>SURNAME:</label>
  <input type="text" name="doc_surname"><?php echo $doc_surname_err;?><br><br>
  
<label>PHONE NUMBER:</label>
  <input type="text" name="doc_phone"><?php echo $doc_phone_err;?><br><br>
  
<input type="submit" value="CREATE" name="create_doc";><br><br>
<?php echo $doc_empty; ?>
<?php echo $add_doc_account_result; ?>

<br>
<h2>Change Patient details</h2>
<?php echo $err_search;?><br>
<label>PATIENT NHS NUMBER:</label>
  <input type="text" name="pat_nhs_search"><br><br>
  <input type="submit" value="SEARCH" name="find_nhs";>

<?php echo $search_res;?><br>

</form>

<br>


</body>
</html>
